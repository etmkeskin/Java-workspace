import java.util.Scanner;

public class Lab4Console {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in); 
		
		//test isPerfect()
				
		//test getVowels()
	
		//test switchLetterCase()
		
		//test digitSum()
		
		//test printFactors()
	
	}	
}
