
public class Lab4 {

	public static boolean isPerfect (int n) {
	

	}
	public static int getVowels (String str) {
		int count = 0;
		
	}
	public static String switchLetterCase (String str) {
		
	}
	public static int digitSum (int number) {
		
	}
	public static String printFactors (int number) {
		
		
	}
}
